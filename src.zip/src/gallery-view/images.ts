import CheckIcon from '../assets/images/check-mark-square.svg';
import CloseIcon from '../assets/images/close.svg';

export {CloseIcon, CheckIcon};
